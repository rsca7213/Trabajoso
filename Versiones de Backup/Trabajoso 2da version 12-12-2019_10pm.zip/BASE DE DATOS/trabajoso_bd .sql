-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-10-2019 a las 14:28:54
-- Versión del servidor: 10.4.6-MariaDB
-- Versión de PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `trabajoso_bd`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulariosaspirantes`
--

CREATE TABLE `formulariosaspirantes` (
  `idAspirante` int(11) NOT NULL,
  `nivelEstudios` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `profesion` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `otraProfesion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `experiencia` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `formulariosaspirantes`
--

INSERT INTO `formulariosaspirantes` (`idAspirante`, `nivelEstudios`, `profesion`, `otraProfesion`, `experiencia`) VALUES
(29, 'Técnico Superior', 'Otro...', 'otroxd', 'yo trabaje desde hace 50 años haciendo cafe de todo tipo que lokis jajaja saludos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulariosempresas`
--

CREATE TABLE `formulariosempresas` (
  `idEmpresa` int(11) NOT NULL,
  `nivelEstudios` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `profesion` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `otraProfesion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `edadBuscada` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `detalles` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios2`
--

CREATE TABLE `usuarios2` (
  `id` int(11) NOT NULL,
  `nombre` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `clave` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `sexo` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `pais` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `perfil` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios2`
--

INSERT INTO `usuarios2` (`id`, `nombre`, `clave`, `correo`, `fecha`, `sexo`, `pais`, `perfil`) VALUES
(1, 'Empresa1', '1234', 'correoEMP1', '0000-00-00', '', 'Argentina', ''),
(2, 'Aspirante1', '1234', 'correoASP1', '1998-01-05', 'M', 'República Dominicana', ''),
(4, 'empresa2', '1234', 'emp2', '0000-00-00', '', 'Panamá', 'empresa'),
(6, 'empresa', '123', '123', '0000-00-00', '', 'Argentina', 'empresa'),
(29, 'Nombre Completo', 'contraseña', 'email@email.com', '1970-01-01', 'F', 'Perú', 'aspirante'),
(31, 'empresita2', '1234', 'empresita2@', '', '', 'Argentina', 'empresa'),
(32, 'nombresito', '1234', 'email@', '2000-12-31', 'M', 'Argentina', 'aspirante');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios2`
--
ALTER TABLE `usuarios2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios2`
--
ALTER TABLE `usuarios2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
