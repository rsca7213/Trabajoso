<?php

		function registrarUsuario(){

			$nombre=$_POST["nombre"];
			$correo=$_POST["email"];
			$clave=$_POST["clave"];
			$sexo=$_POST["sexo"];
			$sexo=$sexo[0];
			$fecha=$_POST["fecha"];
			$fecha2=explode("-",$fecha);
			$hoy=explode("-",date("Y-m-d"));
			$menor=0;
			$pais=$_POST["listaPaisesAspirante"];

			try{
				
				$base= new PDO("mysql:host=localhost; dbname=trabajoso_bd","root","");
				$base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$base->exec("SET CHARACTER SET utf8");

				$sql1="SELECT correo from usuarios2 WHERE correo='" .$correo . "'";
				$resultado=$base->prepare($sql1);
				$resultado->execute(array());
				$filas=$resultado->rowCount();

				if($filas!=0){
					echo("<script type=\"text/javascript\">alert('El correo electrónico ya existe.');</script>");
				}
				else{

					$sql="INSERT INTO usuarios2 (id,nombre,clave,correo,fecha,sexo,pais,perfil) VALUES (0,:nombre,:clave,:email,:fecha,:sexo,:pais,'aspirante')";
					$resultado2=$base->prepare($sql);
					$resultado2->execute(array(":nombre"=>$nombre,":clave"=>$clave,":email"=>$correo,":fecha"=>$fecha,":sexo"=>$sexo,":pais"=>$pais));
				
					echo("<script type=\"text/javascript\">alert('La cuenta ha sido creada exitosamente.');window.location.replace('interfazLogin.php');</script>");
				
					$resultado2->closeCursor();

				}
				$resultado->closeCursor();

				
			}
			catch(Exception $e){
				echo("<script type=\"text/javascript\">alert('Error al conectarse con la base de datos.');</script>");
			}
			finally{
				$base=null;
			}
		}

		function registrarEmpresa(){
			$nombre=$_POST["nombreEmp"];
			$correo=$_POST["email"];
			$clave=$_POST["clave"];
			$pais=$_POST["listaPaisesEmpresa"];

			
			try{
				
				$base= new PDO("mysql:host=localhost; dbname=trabajoso_bd","root","");
				$base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$base->exec("SET CHARACTER SET utf8");

				$sql1="SELECT correo from usuarios2 WHERE correo='" . $correo . "'";
				$resultado=$base->prepare($sql1);
				$resultado->execute(array());
				$filas=$resultado->rowCount();

				if($filas!=0){

					echo("<script type=\"text/javascript\">alert('El correo electrónico ya existe.');</script>");
				}
				else{

					$sql="INSERT INTO usuarios2 (id,nombre,clave,correo,pais,perfil) VALUES (0,:nombre,:clave,:email,:pais,'empresa')";
					$resultado2=$base->prepare($sql);
					$resultado2->execute(array(":nombre"=>$nombre,":clave"=>$clave,":email"=>$correo,":pais"=>$pais));
				
					echo("<script type=\"text/javascript\">alert('La cuenta ha sido creada exitosamente.');window.location.replace('interfazLogin.php');</script>");
				
					$resultado2->closeCursor();

				}
				$resultado->closeCursor();

			}
			catch(Exception $e){
				echo("<script type=\"text/javascript\">alert('Error al conectarse con la base de datos.');</script>");
				echo($e->GetMessage());
			}
			finally{
				$base=null;
			}		
		}
		
		function actualizarPerfilAspirante(){

			$nombre=$_POST["nombre"];
			$correo=$_POST["email"];
			$clave=$_POST["clave"];
			$sexo=$_POST["sexo"];
			$sexo=$sexo[0];
			$fecha=$_POST["fecha"];
			$fecha2=explode("-",$fecha);
			$hoy=explode("-",date("Y-m-d"));
			$menor=0;
			$pais=$_POST["PaisesAspirante"];

			try{
				$base= new PDO("mysql:host=localhost; dbname=trabajoso_bd","root","");
				$base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$base->exec("SET CHARACTER SET utf8");

				$sql1="SELECT id,correo from usuarios2 WHERE correo='" . $correo . "'";
				$resultado=$base->prepare($sql1);
				$resultado->execute(array());
				$filas=$resultado->rowCount();

				if($filas!=0){
					while($registro=$resultado->fetch(PDO::FETCH_ASSOC)){
					
						$idConsultado=$registro['id'];

					}

					if($idConsultado!=$_SESSION['id']){

						echo("<script type=\"text/javascript\">alert('El correo electrónico ya existe.');</script>");
					}else{

						$sql="UPDATE usuarios2 SET nombre=:nombre,clave=:clave,correo=:correo, fecha=:fecha, sexo=:sexo, pais=:pais WHERE id='" . $_SESSION['id'] . "'" ;
						$resultado2=$base->prepare($sql);
						$resultado2->execute(array(":nombre"=>$nombre,":clave"=>$clave,":correo"=>$correo,":fecha"=>$fecha,":sexo"=>$sexo,":pais"=>$pais));
				
						echo("<script type=\"text/javascript\">alert('Perfil actualizado correctamente.');</script>");
				
						$resultado2->closeCursor();

			    	}
				}
				else{

					$sql3="UPDATE usuarios2 SET nombre=:nombre,clave=:clave,correo=:correo, fecha=:fecha, sexo=:sexo, pais=:pais WHERE id='" . $_SESSION['id'] . "'" ;
						$resultado3=$base->prepare($sql3);
						$resultado3->execute(array(":nombre"=>$nombre,":clave"=>$clave,":correo"=>$correo,":fecha"=>$fecha,":sexo"=>$sexo,":pais"=>$pais));
				
						echo("<script type=\"text/javascript\">alert('Perfil actualizado correctamente.');</script>");
				
						$resultado3->closeCursor();
				}
				
				$resultado->closeCursor();
	
			}
			catch(Exception $e){
				echo("<script type=\"text/javascript\">alert('Error al conectarse con la base de datos.');</script>");
			}
			finally{
				$base=null;
			}
		}

		function actualizarPerfilEmpresa(){
			$nombre=$_POST["nameBox"];
			$correo=$_POST["emailBox"];
			$clave=$_POST["passBox"];
			$pais=$_POST["listaPaises"];

			try{
				$base= new PDO("mysql:host=localhost; dbname=trabajoso_bd","root","");
				$base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$base->exec("SET CHARACTER SET utf8");

				$sql1="SELECT id,correo from usuarios2 WHERE correo='" . $correo . "'";
				$resultado=$base->prepare($sql1);
				$resultado->execute(array());
				$filas=$resultado->rowCount();

				if($filas!=0){
					while($registro=$resultado->fetch(PDO::FETCH_ASSOC)){
					
						$idConsultado=$registro['id'];

					}

					if($idConsultado!=$_SESSION['id']){

						echo("<script type=\"text/javascript\">alert('El correo electrónico ya existe.');</script>");
					}else{

						$sql="UPDATE usuarios2 SET nombre=:nombre,clave=:clave,correo=:correo, pais=:pais WHERE id='" . $_SESSION['id'] . "'" ;
						$resultado2=$base->prepare($sql);
						$resultado2->execute(array(":nombre"=>$nombre,":clave"=>$clave,":correo"=>$correo,":pais"=>$pais));
				
						echo("<script type=\"text/javascript\">alert('Perfil actualizado correctamente.');</script>");
				
						$resultado2->closeCursor();

			    	}
				}
				else{

					$sql3="UPDATE usuarios2 SET nombre=:nombre,clave=:clave,correo=:correo,pais=:pais WHERE id='" . $_SESSION['id'] . "'" ;
						$resultado3=$base->prepare($sql3);
						$resultado3->execute(array(":nombre"=>$nombre,":clave"=>$clave,":correo"=>$correo,":pais"=>$pais));
				
						echo("<script type=\"text/javascript\">alert('Perfil actualizado correctamente.');</script>");
				
						$resultado3->closeCursor();
				}
				
				$resultado->closeCursor();
				
			}
			catch(Exception $e){
				echo("<script type=\"text/javascript\">alert('Error al conectarse con la base de datos.');</script>");
			}
			finally{
				$base=null;
			}
		}

		function actualizarFormularioAspirante(){

			$curriculum=$_POST["curriculum"];
			$nivelEstudios=$_POST["educacion"];
			$profesiones=$_POST["listaProfesiones"];
			$otraProfesion=$_POST["otraProfesion"];
			$id=$_SESSION['id'];

			try{
				$base= new PDO("mysql:host=localhost; dbname=trabajoso_bd","root","");
				$base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$base->exec("SET CHARACTER SET utf8");

				$sql1="SELECT idAspirante from formulariosaspirantes WHERE idAspirante='" . $id . "'";
				$resultado=$base->prepare($sql1);
				$resultado->execute(array());
				$filas=$resultado->rowCount();

				if($filas==0){

					$sql="INSERT INTO formulariosaspirantes (idAspirante,nivelEstudios,profesion,otraProfesion,experiencia) VALUES (:id,:nivelEst,:prof,:oProf,:xp)";
					$resultado2=$base->prepare($sql);

					$resultado2->execute(array(":id"=>$id,":nivelEst"=>$nivelEstudios,":prof"=>$profesiones,":oProf"=>$otraProfesion,":xp"=>$curriculum));
				
					echo("<script type=\"text/javascript\">alert('El formulario ha sido creado exitosamente.');</script>");
				
					$resultado2->closeCursor();
				}
				else{

					$sql3="UPDATE formulariosaspirantes SET nivelEstudios=:nivelEst, profesion=:prof, otraProfesion=:oProf, experiencia=:xp WHERE idAspirante='" . $_SESSION['id'] . "'" ;
					$resultado3=$base->prepare($sql3);
					$resultado3->execute(array(":nivelEst"=>$nivelEstudios,":prof"=>$profesiones,":oProf"=>$otraProfesion,":xp"=>$curriculum));
				
					echo("<script type=\"text/javascript\">alert('Formulario actualizado correctamente.');</script>");
				
					$resultado3->closeCursor();

				}
				$resultado->closeCursor();
	
			}
			catch(Exception $e){
				echo("<script type=\"text/javascript\">alert('Error al conectarse con la base de datos.');</script>");
			}
			finally{
				$base=null;
			}
		}

		function actualizarFormularioEmpresa(){
			$detalles=$_POST["detallesText"];
			$edad=$_POST["listaEdad"];
			$nivelEstudios=$_POST["listaEducacion"];
			$profesiones=$_POST["listaProfesiones"];
			$otraProfesion=$_POST["textOtraProf"];
			$id=$_SESSION['id'];

			try{
				$base= new PDO("mysql:host=localhost; dbname=trabajoso_bd","root","");
				$base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$base->exec("SET CHARACTER SET utf8");

				$sql1="SELECT idEmpresa from formulariosempresas WHERE idEmpresa='" . $id . "'";
				$resultado=$base->prepare($sql1);
				$resultado->execute(array());
				$filas=$resultado->rowCount();

				if($filas==0){
					$sql="INSERT INTO formulariosempresas (idEmpresa,nivelEstudios,profesion,otraProfesion,edadBuscada,detalles) VALUES (:id,:nivelEst,:prof,:oProf,:edadB,:details)";
					$resultado2=$base->prepare($sql);

					$resultado2->execute(array(":id"=>$id,":nivelEst"=>$nivelEstudios,":prof"=>$profesiones,":oProf"=>$otraProfesion,":edadB"=>$edad,":details"=>$detalles));
				
					echo("<script type=\"text/javascript\">alert('El formulario ha sido creado exitosamente.');</script>");
				
					$resultado2->closeCursor();
				}
				else{

					$sql3="UPDATE formulariosempresas SET nivelEstudios=:nivelEst, profesion=:prof, otraProfesion=:oProf, edadBuscada=:edadB, detalles=:details WHERE idEmpresa='" . $_SESSION['id'] . "'" ;
					$resultado3=$base->prepare($sql3);
					$resultado3->execute(array(":nivelEst"=>$nivelEstudios,":prof"=>$profesiones,":oProf"=>$otraProfesion,":edadB"=>$edad,":details"=>$detalles));
				
					echo("<script type=\"text/javascript\">alert('Formulario actualizado correctamente.');</script>");
				
					$resultado3->closeCursor();

				}
				$resultado->closeCursor();
				
			}
			catch(Exception $e){
				echo("<script type=\"text/javascript\">alert('Error al conectarse con la base de datos.');</script>");
			}
			finally{
				$base=null;
			}
		}
		
		
			
		?>